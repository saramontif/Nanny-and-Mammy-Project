﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using GoogleMapsApi;
using GoogleMapsApi.Entities.Common;
using GoogleMapsApi.Entities.Directions.Request;
using GoogleMapsApi.Entities.Directions.Response;
using GoogleMapsApi.Entities.Elevation.Request;
using GoogleMapsApi.Entities.Geocoding.Request;
using GoogleMapsApi.Entities.Geocoding.Response;
using GoogleMapsApi.StaticMaps;
using GoogleMapsApi.StaticMaps.Entities;

namespace MapsApiTest
{
    class Program
    {
        static void Main(string[] args)
        {
            // Driving directions
            //var drivingDirectionRequest = new DirectionsRequest
            //{
            //	Origin = "NYC, 5th and 39",
            //	Destination = "Philladephia, Chesnut and Wallnut"
            //};

            var drivingDirectionRequest = new DirectionsRequest
            {
                TravelMode = TravelMode.Walking,
                Origin = "Ha-Va'ad ha-Le'umi 21, JERUSALEM, ISRAEL",
                //Destination = "kfar ivri ,10, Jerusalem,israel"
                Destination = "31.8414894,35.2471631"
            };
            DirectionsResponse drivingDirections = GoogleMaps.Directions.Query(drivingDirectionRequest);
            Leg leg = PrintDirections(drivingDirections);

            Console.WriteLine("**********");
            Console.WriteLine(leg.Distance.Text);
            Console.WriteLine(leg.Duration.Text);
            Console.WriteLine("*****************");

            drivingDirectionRequest.TravelMode = TravelMode.Driving;
            DirectionsResponse drivingDirections2 = GoogleMaps.Directions.Query(drivingDirectionRequest);
            Leg leg2 = PrintDirections(drivingDirections2);

            Console.WriteLine("**********");
            Console.WriteLine(leg2.Distance.Text);
            Console.WriteLine(leg2.Duration.Text);
            Console.WriteLine("*****************");

            Console.ReadKey();


            // Transit directions
            var transitDirectionRequest = new DirectionsRequest
            {
                Origin = "New York",
                Destination = "Queens",
                TravelMode = TravelMode.Transit,
                DepartureTime = DateTime.Now
            };

            DirectionsResponse transitDirections = GoogleMaps.Directions.Query(transitDirectionRequest);
            PrintDirections(transitDirections);


            var dep_time = DateTime.Today
                            .AddDays(1)
                            .AddHours(13);

            var request = new DirectionsRequest
            {
                Origin = "T-centralen, Stockholm, Sverige",
                Destination = "Kungsträdgården, Stockholm, Sverige",
                TravelMode = TravelMode.Transit,
                DepartureTime = dep_time,
                Language = "sv"
            };

            DirectionsResponse result = GoogleMaps.Directions.Query(request);
            PrintDirections(result);

            // Geocode
            //https://maps.googleapis.com/maps/api/geocode/json?address=Parque+Marechal+Mascarenhas+de+Morais&components=locality:Porto%20Aelgre|administrative_area:RS|country:BR
            var geocodeRequest = new GeocodingRequest
            {
                Address = "Parque Marechal Mascarenhas de Morais",
                Components = new GeocodingComponents()
                {
                    Locality = "Porto Alegre",
                    AdministrativeArea = "RS",
                    Country = "BR"
                }

            };

            GeocodingResponse geocode = GoogleMaps.Geocode.Query(geocodeRequest);
            Console.WriteLine(geocode);

            // Static maps API - get static map of with the path of the directions request
            var staticMapGenerator = new StaticMapsEngine();

            //Path from previous directions request
            IEnumerable<Step> steps = drivingDirections.Routes.First().Legs.First().Steps;
            // All start locations
            IList<ILocationString> path = steps.Select(step => step.StartLocation).ToList<ILocationString>();
            // also the end location of the last step
            path.Add(steps.Last().EndLocation);

            string url = staticMapGenerator.GenerateStaticMapURL(new StaticMapRequest(new Location(40.38742, -74.55366), 9, new ImageSize(800, 400))
            {
                Pathes = new List<Path> { new Path
                    {
                        Style = new PathStyle
                        {
                            Color = "red"
                        },
                        Locations = path
                    }},
                ApiKey = string.Empty //Pass the API Key here. if it is passed as non empty value, then it will be appended in request URL
            });

            Console.WriteLine("Map with path: " + url);

            // Async! (Elevation)
            var elevationRequest = new ElevationRequest
            {
                Locations = new[] { new Location(54, 78) },
            };

            var task = GoogleMaps.Elevation.QueryAsync(elevationRequest)
                .ContinueWith(t => Console.WriteLine("\n" + t.Result));

            Console.Write("Asynchronous query sent, waiting for a reply..");

            while (!task.IsCompleted)
            {
                Console.Write('.');
                Thread.Sleep(1000);
            }

            Console.WriteLine("Finished! Press any key to exit...");
            Console.ReadKey();
        }

        private static Leg PrintDirections(DirectionsResponse directions)
        {
            Route route = directions.Routes.First();
            Leg leg = route.Legs.First();
            //string result = leg.Distance.Text;
            foreach (Step step in leg.Steps)
            {
                Console.WriteLine(StripHTML(step.HtmlInstructions));

                var localIcon = step.TransitDetails?.Lines?.Vehicle?.LocalIcon;
                if (localIcon != null)
                    Console.WriteLine("Local sign: " + localIcon);
            }

            Console.WriteLine();
            return leg;
        }

        private static string StripHTML(string html)
        {
            return Regex.Replace(html, @"<(.|\n)*?>", string.Empty);
        }
    }
}